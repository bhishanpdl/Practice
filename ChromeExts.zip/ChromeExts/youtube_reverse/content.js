// content.js - This script runs on YouTube playlist pages and plays videos in reverse order.

(function() {
    function reversePlaylist() {
        const urlParams = new URLSearchParams(window.location.search);
        const listId = urlParams.get('list');
        const index = parseInt(urlParams.get('index'), 10);
        
        if (!listId || isNaN(index)) return;
        
        // Get total number of videos from the UI (or manually set it if known)
        let totalVideos = 28; // Adjust this if needed
        let newIndex = totalVideos - index + 1;
        
        if (newIndex >= 1 && newIndex <= totalVideos) {
            urlParams.set('index', newIndex);
            window.location.search = urlParams.toString();
        }
    }
    
    // Run the function when the page loads
    window.addEventListener('load', reversePlaylist);
})();
